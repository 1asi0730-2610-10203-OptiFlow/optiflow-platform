using optiflow_platform.Shared.Domain.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace optiflow_platform.Shared.Infrastructure.Persistence.EFC.Interceptors;

/// <summary>
///     EF Core interceptor that automatically populates audit timestamps on any entity
///     that implements <see cref="IAuditableEntity"/>.
/// </summary>
/// <remarks>
///     <list type="bullet">
///         <item><description><c>CreatedDate</c> — set once when the entity is first added.</description></item>
///         <item><description><c>UpdatedDate</c> — refreshed on every add or update.</description></item>
///     </list>
///     Register this interceptor in <c>AppDbContext.OnConfiguring</c> so it applies to all
///     bounded contexts sharing the same <see cref="DbContext"/>.
/// </remarks>
public sealed class AuditableEntityInterceptor : SaveChangesInterceptor
{
    /// <inheritdoc />
    public override InterceptionResult<int> SavingChanges(DbContextEventData eventData, InterceptionResult<int> result)
    {
        ApplyAuditTimestamps(eventData.Context);
        return base.SavingChanges(eventData, result);
    }

    /// <inheritdoc />
    public override ValueTask<InterceptionResult<int>> SavingChangesAsync(
        DbContextEventData eventData,
        InterceptionResult<int> result,
        CancellationToken cancellationToken = default)
    {
        ApplyAuditTimestamps(eventData.Context);
        return base.SavingChangesAsync(eventData, result, cancellationToken);
    }

    private static void ApplyAuditTimestamps(DbContext? context)
    {
        if (context is null) return;

        var now = DateTimeOffset.UtcNow;

        foreach (var entry in context.ChangeTracker.Entries<IAuditableEntity>())
        {
            if (entry.State is EntityState.Added or EntityState.Modified) entry.Entity.UpdatedAt = now;
            if (entry.State == EntityState.Added) entry.Entity.CreatedAt ??= now;
        }
    }
}

