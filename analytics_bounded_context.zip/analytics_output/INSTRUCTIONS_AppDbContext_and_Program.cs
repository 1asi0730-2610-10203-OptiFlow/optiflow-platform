// ============================================================
//  INSTRUCCIONES: Agrega estos bloques a los archivos indicados
// ============================================================

// ── 1. AppDbContext.cs ────────────────────────────────────────
// Agrega estos usings en la parte superior del archivo:
//
//   using optiflow_platform.Analytics.Domain.Model.Aggregates;
//   using optiflow_platform.Analytics.Domain.Model.Entities;
//
// Agrega estas líneas DENTRO de OnModelCreating(), después del bloque de WorkOrder:
/*
    // Analytics Bounded Context
    builder.Entity<AnalyticsReport>().HasKey(a => a.Id);
    builder.Entity<AnalyticsReport>().Property(a => a.Id).IsRequired().ValueGeneratedOnAdd();
    builder.Entity<AnalyticsReport>().Property(a => a.GeneratedBy).IsRequired().HasMaxLength(255);
    builder.Entity<AnalyticsReport>().Property(a => a.Period).IsRequired().HasMaxLength(7);
    builder.Entity<AnalyticsReport>().Property(a => a.GeneratedAt).IsRequired();
    builder.Entity<AnalyticsReport>().Property(a => a.TotalRevenue).HasColumnType("decimal(15,2)");
    builder.Entity<AnalyticsReport>().Property(a => a.ConversionRate).HasColumnType("decimal(5,4)");
    builder.Entity<AnalyticsReport>().Property(a => a.AverageDeliveryDays).HasColumnType("decimal(6,2)");
    builder.Entity<AnalyticsReport>().Property(a => a.OnTimeDeliveryRate).HasColumnType("decimal(5,4)");
    builder.Entity<AnalyticsReport>().Property(a => a.ReworkRate).HasColumnType("decimal(5,4)");
    builder.Entity<AnalyticsReport>().Property(a => a.PendingBalance0To7).HasColumnType("decimal(15,2)");
    builder.Entity<AnalyticsReport>().Property(a => a.PendingBalance8To15).HasColumnType("decimal(15,2)");
    builder.Entity<AnalyticsReport>().Property(a => a.PendingBalance16To30).HasColumnType("decimal(15,2)");
    builder.Entity<AnalyticsReport>().Property(a => a.PendingBalanceOver30).HasColumnType("decimal(15,2)");

    builder.Entity<StaffMetric>().HasKey(s => s.Id);
    builder.Entity<StaffMetric>().Property(s => s.Id).IsRequired().ValueGeneratedOnAdd();
    builder.Entity<StaffMetric>().Property(s => s.ReportId).IsRequired();
    builder.Entity<StaffMetric>().Property(s => s.EmployeeName).IsRequired().HasMaxLength(255);
    builder.Entity<StaffMetric>().Property(s => s.TotalRevenue).HasColumnType("decimal(15,2)");
    builder.Entity<StaffMetric>()
        .HasOne<AnalyticsReport>()
        .WithMany()
        .HasForeignKey(s => s.ReportId)
        .OnDelete(DeleteBehavior.Cascade);
*/


// ── 2. Program.cs ─────────────────────────────────────────────
// Agrega estos usings en la parte superior del archivo:
//
//   using optiflow_platform.Analytics.Application.Internal.QueryServices;
//   using optiflow_platform.Analytics.Application.Services;
//   using optiflow_platform.Analytics.Domain.Repositories;
//   using optiflow_platform.Analytics.Infrastructure.Persistence.EFC.Repositories;
//
// Agrega estas líneas en la sección "// Analytics Bounded Context Injection":
/*
    // Analytics Bounded Context Injection
    builder.Services.AddScoped<IAnalyticsReportRepository, AnalyticsReportRepository>();
    builder.Services.AddScoped<IStaffMetricRepository, StaffMetricRepository>();
    builder.Services.AddScoped<IAnalyticsReportQueryService, AnalyticsReportQueryService>();
    builder.Services.AddScoped<IStaffMetricQueryService, StaffMetricQueryService>();
*/
